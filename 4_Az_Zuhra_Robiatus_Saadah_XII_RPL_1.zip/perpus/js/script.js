// Auto hide error after 3 seconds
setTimeout(function() {
    var errorAlert = document.getElementById('errorAlert');
    if(errorAlert) {
        errorAlert.classList.add('error-fadeout');
    }
}, 3000);

// Modal functions untuk transaksi
function editTransaksi(id, status, judul, peminjam) {
    document.getElementById('edit_id').value = id;
    document.getElementById('edit_status').value = status;
    document.getElementById('info_transaksi').innerHTML = `<strong>Buku:</strong> ${judul}<br><strong>Peminjam:</strong> ${peminjam}<br><strong>Status Saat Ini:</strong> ${status.toUpperCase()}`;
    document.getElementById('editModal').classList.remove('hidden');
    document.getElementById('editModal').classList.add('flex');
}

function closeModal() {
    document.getElementById('editModal').classList.add('hidden');
    document.getElementById('editModal').classList.remove('flex');
}

// Confirm sebelum hapus
function confirmDelete(message) {
    return confirm(message);
}

// Search functionality dengan enter key
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.querySelector('input[name="cari"]');
    if(searchInput) {
        searchInput.addEventListener('keypress', function(e) {
            if(e.key === 'Enter') {
                this.form.submit();
            }
        });
    }
});