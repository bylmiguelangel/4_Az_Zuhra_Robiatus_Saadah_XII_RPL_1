<?php if(isset($_SESSION['login']) && $_SESSION['login'] === true): ?>
    </main>
</div>
<?php else: ?>
    </div>
<?php endif; ?>

<script>
    // Toggle Sidebar (hanya jika sidebar ada)
    function toggleSidebar() {
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('overlay');
        const body = document.body;
        
        if(sidebar) {
            sidebar.classList.toggle('open');
            if(overlay) overlay.classList.toggle('open');
            body.classList.toggle('sidebar-open');
        }
    }
    
    // Close Sidebar
    function closeSidebar() {
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('overlay');
        const body = document.body;
        
        if(sidebar) {
            sidebar.classList.remove('open');
            if(overlay) overlay.classList.remove('open');
            body.classList.remove('sidebar-open');
        }
    }
    
    // Tutup sidebar saat klik link di dalam sidebar (untuk mobile)
    if(document.querySelectorAll) {
        document.querySelectorAll('#sidebar a').forEach(link => {
            link.addEventListener('click', () => {
                if(window.innerWidth < 768) {
                    closeSidebar();
                }
            });
        });
    }
    
    // Auto close saat resize ke desktop
    window.addEventListener('resize', function() {
        if(window.innerWidth >= 768) {
            closeSidebar();
        }
    });
</script>

</body>
</html>