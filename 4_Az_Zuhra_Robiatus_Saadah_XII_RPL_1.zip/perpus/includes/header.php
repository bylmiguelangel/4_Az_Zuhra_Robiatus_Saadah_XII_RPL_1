<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Peminjaman Buku</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        /* Sidebar transition */
        .sidebar {
            transition: transform 0.3s ease-in-out;
            transform: translateX(-100%);
            position: fixed;
            top: 0;
            left: 0;
            width: 280px;
            height: 100%;
            z-index: 50;
            background: #1e1b4b;
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
        }
        .sidebar.open {
            transform: translateX(0);
        }
        .overlay {
            transition: opacity 0.3s ease-in-out;
            opacity: 0;
            visibility: hidden;
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,0.5);
            z-index: 40;
        }
        .overlay.open {
            opacity: 1;
            visibility: visible;
        }
        body.sidebar-open {
            overflow: hidden;
        }
    </style>
</head>
<body class="bg-slate-50">

<?php if(isset($_SESSION['login']) && $_SESSION['login'] === true): ?>
<!-- Overlay saat sidebar terbuka -->
<div id="overlay" class="overlay" onclick="closeSidebar()"></div>

<!-- ==================== SIDEBAR (HANYA SETELAH LOGIN) ==================== -->
<aside id="sidebar" class="sidebar">
    <!-- Header Sidebar -->
    <div class="p-6 border-b border-blue-700 flex justify-between items-center">
        <div class="flex items-center gap-3">
            <i class="fas fa-book-open text-3xl text-white"></i>
            <div>
                <h1 class="text-xl font-bold text-white">Peminjaman</h1>
                <p class="text-xs text-blue-300">Buku Digital</p>
            </div>
        </div>
        <button onclick="closeSidebar()" class="text-blue-300 hover:text-white transition">
            <i class="fas fa-times text-xl"></i>
        </button>
    </div>
    
    <!-- Menu Navigasi -->
    <nav class="flex-1 py-6 px-4 space-y-2 overflow-y-auto">
        <!-- Dashboard -->
        <a href="?menu=dashboard" class="flex items-center gap-3 px-4 py-3 rounded-xl transition duration-200 <?php echo ($menu=='dashboard') ? 'bg-blue-600 text-white' : 'text-blue-200 hover:bg-blue-700 hover:text-white'; ?>">
            <i class="fas fa-tachometer-alt w-5"></i>
            <span>Dashboard</span>
        </a>
        
        <!-- Data Buku -->
        <a href="?menu=buku" class="flex items-center gap-3 px-4 py-3 rounded-xl transition duration-200 <?php echo ($menu=='buku') ? 'bg-blue-600 text-white' : 'text-blue-200 hover:bg-blue-700 hover:text-white'; ?>">
            <i class="fas fa-book w-5"></i>
            <span>Data Buku</span>
        </a>
        
        <!-- Transaksi -->
        <a href="?menu=transaksi" class="flex items-center gap-3 px-4 py-3 rounded-xl transition duration-200 <?php echo ($menu=='transaksi') ? 'bg-blue-600 text-white' : 'text-blue-200 hover:bg-blue-700 hover:text-white'; ?>">
            <i class="fas fa-exchange-alt w-5"></i>
            <span>Transaksi</span>
        </a>
        
        <!-- Menu Khusus Admin -->
        <?php if($_SESSION['role'] == 'admin'): ?>
            <div class="pt-4 mt-4 border-t border-blue-700">
                <p class="text-xs text-blue-400 px-4 mb-2 uppercase tracking-wider">Manajemen</p>
                
                <a href="?menu=anggota" class="flex items-center gap-3 px-4 py-3 rounded-xl transition duration-200 <?php echo ($menu=='anggota') ? 'bg-blue-600 text-white' : 'text-blue-200 hover:bg-blue-700 hover:text-white'; ?>">
                    <i class="fas fa-users w-5"></i>
                    <span>Anggota</span>
                </a>
                
                <a href="?menu=log" class="flex items-center gap-3 px-4 py-3 rounded-xl transition duration-200 <?php echo ($menu=='log') ? 'bg-blue-600 text-white' : 'text-blue-200 hover:bg-blue-700 hover:text-white'; ?>">
                    <i class="fas fa-history w-5"></i>
                    <span>Log Aktivitas</span>
                </a>
            </div>
        <?php endif; ?>
        
        <!-- Logout -->
        <div class="pt-4 mt-4 border-t border-blue-700">
            <a href="?menu=logout" class="flex items-center gap-3 px-4 py-3 rounded-xl transition duration-200 text-blue-200 hover:bg-blue-700 hover:text-white" onclick="return confirm('Yakin ingin logout?')">
                <i class="fas fa-sign-out-alt w-5"></i>
                <span>Logout</span>
            </a>
        </div>
    </nav>
    
    <!-- Footer Sidebar (User Info) -->
    <div class="p-4 border-t border-blue-700">
        <div class="flex items-center gap-3">
            <div class="w-10 h-10 rounded-full bg-blue-600 flex items-center justify-center">
                <i class="fas fa-user text-white"></i>
            </div>
            <div class="flex-1">
                <p class="font-semibold text-sm text-white"><?php echo $_SESSION['nama']; ?></p>
                <p class="text-xs text-blue-300"><?php echo $_SESSION['role']; ?></p>
            </div>
        </div>
    </div>
</aside>

<!-- ==================== MAIN CONTENT (SETELAH LOGIN) ==================== -->
<div class="flex-1 flex flex-col min-h-screen">
    
    <!-- Top Navbar dengan Burger Button -->
    <nav class="bg-white shadow-sm sticky top-0 z-30">
        <div class="px-6 py-4 flex justify-between items-center">
            <!-- Burger Button -->
            <button onclick="toggleSidebar()" class="text-blue-600 hover:text-blue-800 focus:outline-none">
                <i class="fas fa-bars text-2xl"></i>
            </button>
            
            <div class="flex items-center gap-4">
                <span class="font-bold text-xl text-slate-700">Peminjaman Buku</span>
                
                <div class="flex items-center gap-2 bg-slate-100 px-3 py-1 rounded-full">
                    <i class="fas fa-user-circle text-blue-600"></i>
                    <span class="text-sm text-slate-600"><?php echo $_SESSION['nama']; ?></span>
                </div>
            </div>
        </div>
    </nav>
    
    <!-- Main Content Area -->
    <main class="p-6">
        
<?php else: ?>
    <!-- ==================== TAMPILAN UNTUK LOGIN/DAFTAR (NAVBAR NORMAL) ==================== -->
    
    <!-- Navbar Normal (Seperti Semula) -->
    <nav class="bg-white border-b sticky top-0 z-50">
        <div class="container mx-auto px-6 py-4 flex justify-between items-center">
            <div class="flex items-center gap-2 font-bold text-2xl text-blue-600">
                <span>Peminjaman Buku</span>
            </div>
            <div class="hidden md:flex items-center gap-6">
                <a href="?menu=login" class="<?php echo ($menu=='login') ? 'bg-blue-600 text-white px-6 py-2 rounded-full shadow-lg' : 'text-slate-600 hover:text-blue-600'; ?>">Masuk</a>
                <a href="?menu=daftar" class="<?php echo ($menu=='daftar') ? 'bg-blue-600 text-white px-6 py-2 rounded-full shadow-lg' : 'bg-blue-50 text-blue-600 px-6 py-2 rounded-full hover:bg-blue-100'; ?>">Daftar</a>
            </div>
        </div>
    </nav>
    
    <!-- Container untuk halaman login/daftar -->
    <div class="container mx-auto px-6 py-10">
<?php endif; ?>