<?php
function logActivity($conn, $user_id, $action, $details) {
    $query = "INSERT INTO activity_log (user_id, action, details, created_at) VALUES ($user_id, '$action', '$details', NOW())";
    mysqli_query($conn, $query);
}

function getStokBuku($conn, $id_buku) {
    $q = mysqli_query($conn, "SELECT stok FROM buku WHERE id=$id_buku");
    $data = mysqli_fetch_assoc($q);
    return $data['stok'];
}

function updateStokBuku($conn, $id_buku, $jumlah) {
    mysqli_query($conn, "UPDATE buku SET stok = stok + $jumlah WHERE id=$id_buku");
}
?>