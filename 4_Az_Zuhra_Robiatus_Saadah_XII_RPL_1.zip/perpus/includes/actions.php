<?php
// Proses Daftar (LANGSUNG LOGIN OTOMATIS)
if(isset($_POST['daftar'])){
    $nama = mysqli_real_escape_string($conn, $_POST['nama']);
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    
    // Cek apakah username sudah terdaftar
    $cek = mysqli_query($conn, "SELECT * FROM users WHERE username='$username'");
    if(mysqli_num_rows($cek) > 0){
        $_SESSION['error_msg'] = "Username sudah terdaftar!";
        header("Location: index.php?menu=daftar");
        exit();
    }
    
    // Insert user baru (role = user)
    $query = "INSERT INTO users VALUES(NULL, '$nama', '$username', '$password', 'user')";
    if(mysqli_query($conn, $query)){
        // Ambil data user yang baru saja didaftarkan
        $user_id = mysqli_insert_id($conn);
        
        // Set session untuk login otomatis
        $_SESSION['login'] = true;
        $_SESSION['id'] = $user_id;
        $_SESSION['role'] = 'user';
        $_SESSION['nama'] = $nama;
        
        // Redirect langsung ke dashboard
        header("Location: index.php?menu=dashboard");
        exit();
    } else {
        $_SESSION['error_msg'] = "Pendaftaran gagal, silakan coba lagi!";
        header("Location: index.php?menu=daftar");
        exit();
    }
}

// Proses Login
if(isset($_POST['login'])){  
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    
    $q = mysqli_query($conn, "SELECT * FROM users WHERE username='$username' AND password='$password'");
    
    if(mysqli_num_rows($q) > 0){
        $d = mysqli_fetch_assoc($q);
        //menyimpan sekumpulan data dengan tipe yang sama
        // Set session dengan benar
        $_SESSION['login'] = true; 
        $_SESSION['id'] = $d['id']; 
        $_SESSION['role'] = $d['role']; 
        $_SESSION['nama'] = $d['nama'];
        
        // Redirect ke dashboard
        header("Location: index.php?menu=dashboard");
        exit();
    } else {
        $_SESSION['login_error'] = "Username atau password salah!";
        header("Location: index.php?menu=login");
        exit();
    }
}

// Logout
if($menu == "logout"){ 
    session_destroy(); 
    header("Location: index.php?menu=login"); 
    exit();
}

// Proses Pinjam Buku
if(isset($_GET['pinjam'])){
    $id_buku = $_GET['pinjam'];
    $cek = mysqli_query($conn, "SELECT stok FROM buku WHERE id=$id_buku");
    $b = mysqli_fetch_assoc($cek);
    
    if($b['stok'] > 0){
        // Insert transaksi
        $query_trans = "INSERT INTO transaksi VALUES(NULL, $_SESSION[id], $id_buku, CURDATE(), NULL, 'dipinjam')";
        mysqli_query($conn, $query_trans);
        
        // Update stok
        mysqli_query($conn, "UPDATE buku SET stok = stok - 1 WHERE id=$id_buku");
        
        // 🔵 INSERT LOG AKTIVITAS (PINJAM BUKU) 🔵
        $user_id = $_SESSION['id'];
        $action = 'MEMINJAM';
        $details = "Meminjam buku ID: $id_buku";
        $log_query = "INSERT INTO activity_log (user_id, action, details, created_at) VALUES ($user_id, '$action', '$details', NOW())";
        mysqli_query($conn, $log_query);
        
        $_SESSION['success_msg'] = "Buku berhasil dipinjam!";
    } else {
        $_SESSION['error_msg'] = "Stok buku habis!";
    }
    header("Location: index.php?menu=transaksi");
    exit();
}

// Proses Kembalikan Buku (oleh user)
if(isset($_GET['kembali'])){
    $id_t = $_GET['kembali'];
    $cek_user = mysqli_query($conn, "SELECT user_id, buku_id FROM transaksi WHERE id=$id_t");
    $data = mysqli_fetch_assoc($cek_user);
    
    if($_SESSION['role'] == 'admin' || $data['user_id'] == $_SESSION['id']){
        mysqli_query($conn,"UPDATE transaksi SET status='dikembalikan', tgl_kembali=CURDATE() WHERE id=$id_t");
        mysqli_query($conn,"UPDATE buku SET stok = stok + 1 WHERE id=".$data['buku_id']);
        
        // 🔵 INSERT LOG AKTIVITAS (KEMBALIKAN BUKU) 🔵
        $user_id = $_SESSION['id'];
        $action = 'MENGEMBALIKAN';
        $details = "Mengembalikan transaksi ID: $id_t";
        $log_query = "INSERT INTO activity_log (user_id, action, details, created_at) VALUES ($user_id, '$action', '$details', NOW())";
        mysqli_query($conn, $log_query);
        
        $_SESSION['success_msg'] = "Buku berhasil dikembalikan!";
    } else {
        $_SESSION['error_msg'] = "Anda tidak memiliki akses!";
    }
    header("Location: index.php?menu=transaksi");
    exit();
}

// Admin: Update status transaksi
if(isset($_POST['update_status_transaksi'])){
    $id_transaksi = $_POST['id_transaksi'];
    $status_baru = $_POST['status'];
    $alasan = $_POST['alasan'];
    
    $q_trans = mysqli_query($conn, "SELECT * FROM transaksi WHERE id=$id_transaksi");
    $trans = mysqli_fetch_assoc($q_trans);
    
    if($status_baru == 'dikembalikan' && $trans['status'] == 'dipinjam'){
        mysqli_query($conn, "UPDATE buku SET stok = stok + 1 WHERE id=".$trans['buku_id']);
        mysqli_query($conn, "UPDATE transaksi SET status='dikembalikan', tgl_kembali=CURDATE() WHERE id=$id_transaksi");
        
        // 🔵 INSERT LOG AKTIVITAS (ADMIN KEMBALIKAN) 🔵
        $user_id = $_SESSION['id'];
        $action = 'ADMIN_KEMBALIKAN';
        $details = "Admin mengembalikan transaksi ID: $id_transaksi. Alasan: $alasan";
        $log_query = "INSERT INTO activity_log (user_id, action, details, created_at) VALUES ($user_id, '$action', '$details', NOW())";
        mysqli_query($conn, $log_query);
        
        $_SESSION['success_msg'] = "Status transaksi berhasil diubah menjadi Dikembalikan";
    } 
    elseif($status_baru == 'dipinjam' && $trans['status'] == 'dikembalikan'){
        mysqli_query($conn, "UPDATE buku SET stok = stok - 1 WHERE id=".$trans['buku_id']);
        mysqli_query($conn, "UPDATE transaksi SET status='dipinjam', tgl_kembali=NULL WHERE id=$id_transaksi");
        
        // 🔵 INSERT LOG AKTIVITAS (ADMIN BATAL KEMBALI) 🔵
        $user_id = $_SESSION['id'];
        $action = 'ADMIN_BATAL_KEMBALI';
        $details = "Admin membatalkan pengembalian transaksi ID: $id_transaksi. Alasan: $alasan";
        $log_query = "INSERT INTO activity_log (user_id, action, details, created_at) VALUES ($user_id, '$action', '$details', NOW())";
        mysqli_query($conn, $log_query);
        
        $_SESSION['success_msg'] = "Status transaksi berhasil diubah menjadi Dipinjam";
    }
    header("Location: index.php?menu=transaksi");
    exit();
}

// Admin: Hapus transaksi
if(isset($_GET['hapus_transaksi'])){
    $id_transaksi = $_GET['hapus_transaksi'];
    $q_trans = mysqli_query($conn, "SELECT * FROM transaksi WHERE id=$id_transaksi");
    $trans = mysqli_fetch_assoc($q_trans);
    
    if($trans['status'] == 'dipinjam'){
        mysqli_query($conn, "UPDATE buku SET stok = stok + 1 WHERE id=".$trans['buku_id']);
    }
    mysqli_query($conn, "DELETE FROM transaksi WHERE id=$id_transaksi");
    
    // 🔵 INSERT LOG AKTIVITAS (HAPUS TRANSAKSI) 🔵
    $user_id = $_SESSION['id'];
    $action = 'HAPUS_TRANSAKSI';
    $details = "Menghapus transaksi ID: $id_transaksi";
    $log_query = "INSERT INTO activity_log (user_id, action, details, created_at) VALUES ($user_id, '$action', '$details', NOW())";
    mysqli_query($conn, $log_query);
    
    $_SESSION['success_msg'] = "Transaksi berhasil dihapus!";
    header("Location: index.php?menu=transaksi");
    exit();
}

// CRUD Buku
if(isset($_POST['tambah_buku'])){
    mysqli_query($conn,"INSERT INTO buku VALUES(NULL,'$_POST[judul]','$_POST[pengarang]','$_POST[stok]')");
    $_SESSION['success_msg'] = "Buku berhasil ditambahkan!";
    header("Location: index.php?menu=buku");
    exit();
}

if(isset($_POST['edit_buku'])){
    mysqli_query($conn,"UPDATE buku SET judul='$_POST[judul]', pengarang='$_POST[pengarang]', stok='$_POST[stok]' WHERE id=$_POST[id]");
    $_SESSION['success_msg'] = "Buku berhasil diupdate!";
    header("Location: index.php?menu=buku");
    exit();
}

if(isset($_GET['hapus_buku'])){
    mysqli_query($conn,"DELETE FROM buku WHERE id=$_GET[hapus_buku]");
    $_SESSION['success_msg'] = "Buku berhasil dihapus!";
    header("Location: index.php?menu=buku");
    exit();
}

// CRUD User (Anggota)
if(isset($_POST['edit_user'])){
    $id = $_POST['id'];
    $nama = $_POST['nama'];
    $username = $_POST['username'];
    $password = $_POST['password'];

    if(!empty($password)){
        mysqli_query($conn,"UPDATE users SET nama='$nama', username='$username', password='$password' WHERE id=$id");
    } else {
        mysqli_query($conn,"UPDATE users SET nama='$nama', username='$username' WHERE id=$id");
    }
    $_SESSION['success_msg'] = "Anggota berhasil diupdate!";
    header("Location: index.php?menu=anggota");
    exit();
}

if(isset($_GET['hapus_user'])){
    mysqli_query($conn,"DELETE FROM users WHERE id=$_GET[hapus_user]");
    $_SESSION['success_msg'] = "Anggota berhasil dihapus!";
    header("Location: index.php?menu=anggota");
    exit();
}

// Edit Transaksi dengan GET (Form Sederhana)
if(isset($_GET['edit_id'])){
    $id_transaksi = $_GET['edit_id'];
    $q = mysqli_query($conn, "SELECT * FROM transaksi WHERE id=$id_transaksi");
    $data = mysqli_fetch_assoc($q);
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <title>Edit Transaksi</title>
        <script src="https://cdn.tailwindcss.com"></script>
    </head>
    <body class="bg-slate-100">
        <div class="min-h-screen flex items-center justify-center p-4">
            <div class="bg-white rounded-2xl p-8 max-w-md w-full shadow-2xl">
                <h2 class="text-2xl font-bold mb-4 text-slate-800">Edit Status Transaksi</h2>
                <form method="post" action="index.php?menu=transaksi">
                    <input type="hidden" name="id_transaksi" value="<?php echo $id_transaksi; ?>">
                    
                    <div class="mb-4 p-3 bg-slate-50 rounded-xl">
                        <p class="text-sm text-slate-600">
                            <strong>Buku ID:</strong> <?php echo $data['buku_id']; ?><br>
                            <strong>Status Saat Ini:</strong> <?php echo strtoupper($data['status']); ?>
                        </p>
                    </div>
                    
                    <div class="mb-4">
                        <label class="block text-slate-700 font-semibold mb-2">Ubah Status Menjadi</label>
                        <select name="status" class="w-full px-4 py-2 border rounded-xl focus:ring-2 focus:ring-blue-500">
                            <option value="dipinjam" <?php echo ($data['status']=='dipinjam') ? 'selected' : ''; ?>>Dipinjam</option>
                            <option value="dikembalikan" <?php echo ($data['status']=='dikembalikan') ? 'selected' : ''; ?>>Dikembalikan</option>
                        </select>
                    </div>
                    
                    <div class="mb-6">
                        <label class="block text-slate-700 font-semibold mb-2">Alasan Perubahan</label>
                        <textarea name="alasan" rows="3" class="w-full px-4 py-2 border rounded-xl" placeholder="Contoh: Salah klik, Force Return" required></textarea>
                    </div>
                    
                    <div class="flex gap-3">
                        <a href="index.php?menu=transaksi" class="flex-1 bg-slate-300 text-slate-700 py-2 rounded-xl text-center font-semibold hover:bg-slate-400">Batal</a>
                        <button type="submit" name="update_status_transaksi" class="flex-1 bg-blue-600 text-white py-2 rounded-xl font-semibold hover:bg-blue-700">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </body>
    </html>
    <?php
    exit();
}

?>