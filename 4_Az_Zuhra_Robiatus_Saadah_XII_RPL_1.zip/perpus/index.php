<?php
session_start(); // HARUS di baris PALING ATAS
require_once 'config/database.php';
require_once 'includes/functions.php';

$menu = isset($_GET['menu']) ? $_GET['menu'] : 'dashboard';

// CEK LOGIN: Jika belum login dan bukan akses ke halaman login/daftar
if(!isset($_SESSION['login']) && $menu != 'login' && $menu != 'daftar' && $menu != 'logout'){
    header("Location: index.php?menu=login");
    exit();
}

// Proses semua POST & GET actions
include 'includes/actions.php';

// Tampilkan header
include 'includes/header.php';

// Tampilkan konten sesuai menu
switch($menu) {
    case 'login':
        if(isset($_SESSION['login'])){
            header("Location: index.php?menu=dashboard");
            exit();
        }
        include 'pages/login.php';
        break;
    case 'daftar':
        if(isset($_SESSION['login'])){
            header("Location: index.php?menu=dashboard");
            exit();
        }
        include 'pages/daftar.php';
        break;
    case 'dashboard':
        if(!isset($_SESSION['login'])) {
            header("Location: index.php?menu=login");
            exit();
        }
        include 'pages/dashboard.php';
        break;
    case 'buku':
        if(!isset($_SESSION['login'])) {
            header("Location: index.php?menu=login");
            exit();
        }
        include 'pages/buku.php';
        break;
    case 'transaksi':
        if(!isset($_SESSION['login'])) {
            header("Location: index.php?menu=login");
            exit();
        }
        include 'pages/transaksi.php';
        break;
    case 'anggota':
        if(!isset($_SESSION['login']) || $_SESSION['role'] != 'admin') {
            header("Location: index.php?menu=login");
            exit();
        }
        include 'pages/anggota.php';
        break;
    case 'log':
        if(!isset($_SESSION['login']) || $_SESSION['role'] != 'admin') {
            header("Location: index.php?menu=login");
            exit();
        }
        include 'pages/log.php';
        break;
    default:
        include 'pages/404.php';
}

// Tampilkan footer
include 'includes/footer.php';
?>