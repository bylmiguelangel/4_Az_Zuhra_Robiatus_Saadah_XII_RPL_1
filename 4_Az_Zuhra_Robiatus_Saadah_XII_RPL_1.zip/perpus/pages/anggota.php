<div class="flex flex-col gap-6">
    <?php 
    if(isset($_GET['edit'])){
        $res = mysqli_query($conn, "SELECT * FROM users WHERE id=$_GET[edit]");
        $edit_user = mysqli_fetch_assoc($res);
    ?>
    <div class="bg-orange-50 p-6 rounded-2xl shadow-sm border border-orange-200">
        <h4 class="font-bold text-lg mb-4 flex items-center gap-2 text-orange-700">
            <i class="fas fa-user-edit"></i> Edit Anggota
        </h4>
        <form method="post" class="grid grid-cols-1 md:grid-cols-4 gap-4">
            <input type="hidden" name="id" value="<?= $edit_user['id'] ?>">
            <input name="nama" value="<?= htmlspecialchars($edit_user['nama']) ?>" class="border p-3 rounded-xl outline-none focus:ring-2 focus:ring-orange-500" placeholder="Nama Lengkap" required>
            <input name="username" value="<?= htmlspecialchars($edit_user['username']) ?>" class="border p-3 rounded-xl outline-none focus:ring-2 focus:ring-orange-500" placeholder="Username" required>
            <input type="password" name="password" class="border p-3 rounded-xl outline-none focus:ring-2 focus:ring-orange-500" placeholder="Isi jika ingin ganti password">
            <div class="flex gap-2">
                <button name="edit_user" class="bg-orange-600 text-white px-4 rounded-xl font-bold flex-1 hover:bg-orange-700 transition">Update</button>
                <a href="?menu=anggota" class="bg-slate-400 text-white px-4 py-3 rounded-xl text-center hover:bg-slate-500 transition">Batal</a>
            </div>
        </form>
        <p class="text-xs text-orange-600 mt-2">* Kosongkan password jika tidak ingin mengubahnya.</p>
    </div>
    <?php } ?>

    <div class="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <div class="p-6 border-b bg-slate-50/50 flex justify-between items-center">
            <h3 class="font-bold text-xl">👥 Kelola Anggota</h3>
            <div class="text-sm text-slate-500">
                <i class="fas fa-users"></i> Total: 
                <?php 
                    $total = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM users WHERE role='user'"));
                    echo $total['total']; 
                ?> Anggota
            </div>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-left">
                <thead class="bg-slate-50 text-slate-500 uppercase text-xs">
                    <tr>
                        <th class="px-6 py-4">No</th>
                        <th class="px-6 py-4">Nama Lengkap</th>
                        <th class="px-6 py-4">Username</th>
                        <th class="px-6 py-4">Bergabung Sejak</th>
                        <th class="px-6 py-4 text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                    <?php
                    $no = 1;
                    $q = mysqli_query($conn, "SELECT * FROM users WHERE role='user' ORDER BY id DESC");
                    if(mysqli_num_rows($q) > 0){
                        while($u = mysqli_fetch_assoc($q)){
                    ?>
                    <tr class="hover:bg-slate-50 transition">
                        <td class="px-6 py-4 text-slate-500"><?php echo $no++; ?></td>
                        <td class="px-6 py-4 font-bold"><?php echo htmlspecialchars($u['nama']); ?></td>
                        <td class="px-6 py-4 text-slate-600">@<?php echo htmlspecialchars($u['username']); ?></td>
                        <td class="px-6 py-4 text-sm text-slate-500"><?php echo date('d/m/Y', strtotime($u['created_at'] ?? 'now')); ?></td>
                        <td class="px-6 py-4 text-center flex justify-center gap-3">
                            <a href="?menu=anggota&edit=<?php echo $u['id']; ?>" class="text-blue-600 hover:text-blue-800 bg-blue-50 px-3 py-2 rounded-lg transition">
                                <i class="fas fa-edit"></i> Edit
                            </a>
                            <a href="?menu=anggota&hapus_user=<?php echo $u['id']; ?>" class="text-red-500 hover:text-red-700 bg-red-50 px-3 py-2 rounded-lg transition" onclick="return confirm('Hapus anggota <?php echo $u['nama']; ?>? Semua riwayat peminjaman akan terhapus')">
                                <i class="fas fa-trash"></i> Hapus
                            </a>
                        </td>
                    </tr>
                    <?php 
                        }
                    } else {
                    ?>
                    <tr>
                        <td colspan="5" class="px-6 py-12 text-center text-slate-500">
                            <i class="fas fa-user-slash text-4xl mb-2 block"></i>
                            Belum ada anggota terdaftar
                        </td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>