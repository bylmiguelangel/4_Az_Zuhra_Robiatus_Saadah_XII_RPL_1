<div class="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
    <div class="p-6 border-b bg-slate-50/50 flex justify-between items-center flex-wrap gap-4">
        <h3 class="font-bold text-xl text-slate-800">📋 Riwayat Peminjaman</h3>
        <?php if($_SESSION['role'] == 'admin'): ?>
            <span class="text-xs text-blue-600 bg-blue-50 px-3 py-1 rounded-full">
                <i class="fas fa-shield-alt"></i> Mode Admin - Klik tombol biru untuk edit transaksi
            </span>
        <?php endif; ?>
    </div>
    <div class="overflow-x-auto">
        <table class="w-full text-left">
            <thead class="bg-slate-50 text-slate-500 uppercase text-xs">
                <tr>
                    <th class="px-6 py-4">Buku</th>
                    <?php if($_SESSION['role']=='admin') echo "<th class='px-6 py-4'>Peminjam</th>"; ?>
                    <th class="px-6 py-4">Tgl Pinjam</th>
                    <th class="px-6 py-4">Tgl Kembali</th>
                    <th class="px-6 py-4">Status</th>
                    <th class="px-6 py-4 text-center">Aksi</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
                <?php
                // ========== PERBAIKAN QUERY ==========
                // User hanya melihat transaksi miliknya sendiri
                if($_SESSION['role'] == 'user'){
                    $q = mysqli_query($conn, "SELECT transaksi.*, users.nama, users.id as user_id, buku.judul 
                        FROM transaksi 
                        JOIN users ON transaksi.user_id = users.id 
                        JOIN buku ON transaksi.buku_id = buku.id 
                        WHERE transaksi.user_id = " . $_SESSION['id'] . "
                        ORDER BY transaksi.id DESC");
                } else {
                    // Admin melihat semua transaksi
                    $q = mysqli_query($conn, "SELECT transaksi.*, users.nama, users.id as user_id, buku.judul 
                        FROM transaksi 
                        JOIN users ON transaksi.user_id = users.id 
                        JOIN buku ON transaksi.buku_id = buku.id 
                        ORDER BY transaksi.id DESC");
                }
                // ===================================
                
                if(mysqli_num_rows($q) > 0){
                    while($t = mysqli_fetch_assoc($q)){
                        $tgl_kembali = ($t['tgl_kembali'] != null) ? $t['tgl_kembali'] : '-';
                ?>
                <tr class="hover:bg-slate-50 transition">
                    <td class="px-6 py-4 font-medium"><?php echo htmlspecialchars($t['judul']); ?></td>
                    <?php if($_SESSION['role']=='admin') echo "<td class='px-6 py-4 text-slate-600 font-bold'>".htmlspecialchars($t['nama'])."</td>"; ?>
                    <td class="px-6 py-4 text-sm"><?php echo $t['tgl_pinjam']; ?></td>
                    <td class="px-6 py-4 text-sm"><?php echo $tgl_kembali; ?></td>
                    <td class="px-6 py-4">
                        <span class="px-3 py-1 rounded-full text-[10px] font-bold <?php echo $t['status']=='dipinjam' ? 'bg-amber-100 text-amber-700' : 'bg-green-100 text-green-700'; ?>">
                            <i class="fas <?php echo $t['status']=='dipinjam' ? 'fa-clock' : 'fa-check-circle'; ?> mr-1"></i>
                            <?php echo strtoupper($t['status']); ?>
                        </span>
                    </td>
                    <td class="px-6 py-4 text-center">
                        <div class="flex justify-center gap-2">
                            <?php if($t['status']=='dipinjam'): ?>
                                <a href="?kembali=<?php echo $t['id']; ?>" class="bg-emerald-500 text-white px-4 py-2 rounded-lg text-xs font-bold hover:bg-emerald-600 transition" onclick="return confirm('Kembalikan buku <?php echo addslashes($t['judul']); ?>?')">
                                    <i class="fas fa-undo-alt"></i> KEMBALI
                                </a>
                            <?php else: ?>
                                <span class="text-slate-400 text-xs italic"><i class="fas fa-check-circle"></i> Selesai</span>
                            <?php endif; ?>
                            
                            <?php if($_SESSION['role'] == 'admin'): ?>
                                <a href="?menu=transaksi&edit_id=<?php echo $t['id']; ?>" 
                                   class="bg-blue-500 text-white px-3 py-2 rounded-lg text-xs font-bold hover:bg-blue-600 transition inline-block text-center">
                                    <i class="fas fa-edit"></i> Edit
                                </a>
                                <a href="?hapus_transaksi=<?php echo $t['id']; ?>" class="bg-red-500 text-white px-3 py-2 rounded-lg text-xs font-bold hover:bg-red-600 transition" onclick="return confirm('Hapus transaksi ini? Stok akan dikembalikan otomatis')">
                                    <i class="fas fa-trash"></i> Hapus
                                </a>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php 
                    }
                } else {
                ?>
                <tr>
                    <td colspan="<?php echo ($_SESSION['role']=='admin') ? '6' : '5'; ?>" class="px-6 py-12 text-center text-slate-500">
                        <i class="fas fa-inbox text-4xl mb-2 block"></i>
                        <?php if($_SESSION['role'] == 'user'): ?>
                            Anda belum pernah meminjam buku
                            <br>
                            <a href="?menu=buku" class="text-blue-600 text-sm mt-2 inline-block">→ Pinjam Buku Sekarang</a>
                        <?php else: ?>
                            Belum ada riwayat peminjaman
                            <br>
                            <a href="?menu=buku" class="text-blue-600 text-sm mt-2 inline-block">→ Tambah Buku Sekarang</a>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>