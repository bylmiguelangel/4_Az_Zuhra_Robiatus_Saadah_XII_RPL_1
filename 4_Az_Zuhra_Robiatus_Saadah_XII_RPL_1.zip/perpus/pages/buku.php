<div class="flex flex-col gap-6">
    <?php if($_SESSION['role']=='admin'){ 
        if(isset($_GET['edit'])){
            $res = mysqli_query($conn, "SELECT * FROM buku WHERE id=$_GET[edit]");
            $edit_data = mysqli_fetch_assoc($res);
        ?>
        <div class="bg-indigo-50 p-6 rounded-2xl shadow-sm border border-indigo-200">
            <h4 class="font-bold text-lg mb-4 flex items-center gap-2 text-indigo-700">
                <i class="fas fa-edit"></i> Edit Buku
            </h4>
            <form method="post" class="grid grid-cols-1 md:grid-cols-4 gap-4">
                <input type="hidden" name="id" value="<?= $edit_data['id'] ?>">
                <input name="judul" value="<?= $edit_data['judul'] ?>" class="border p-3 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500" required>
                <input name="pengarang" value="<?= $edit_data['pengarang'] ?>" class="border p-3 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500" required>
                <input name="stok" type="number" value="<?= $edit_data['stok'] ?>" class="border p-3 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500" required>
                <div class="flex gap-2">
                    <button name="edit_buku" class="bg-indigo-600 text-white px-4 rounded-xl font-bold flex-1">Update</button>
                    <a href="?menu=buku" class="bg-slate-400 text-white px-4 py-3 rounded-xl text-center">Batal</a>
                </div>
            </form>
        </div>
        <?php } else { ?>
        <div class="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
            <h4 class="font-bold text-lg mb-4 flex items-center gap-2">📚 Tambah Buku</h4>
            <form method="post" class="grid grid-cols-1 md:grid-cols-4 gap-4">
                <input name="judul" placeholder="Judul Buku" class="border p-3 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500" required>
                <input name="pengarang" placeholder="Pengarang" class="border p-3 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500" required>
                <input name="stok" type="number" placeholder="Stok" class="border p-3 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500" required>
                <button name="tambah_buku" class="bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition">Simpan</button>
            </form>
        </div>
        <?php } ?>
    <?php } ?>

    <div class="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <div class="p-6 border-b flex flex-col md:flex-row justify-between items-center gap-4 bg-slate-50/50">
            <h3 class="font-bold text-xl">📖 Katalog Buku</h3>
            <form method="get" class="flex gap-2 w-full md:w-auto">
                <input type="hidden" name="menu" value="buku">
                <input name="cari" placeholder="Cari judul/pengarang..." class="border px-4 py-2 rounded-full text-sm outline-none focus:ring-2 focus:ring-indigo-500 w-full" value="<?php echo isset($_GET['cari']) ? $_GET['cari'] : ''; ?>">
                <button class="bg-indigo-600 text-white px-4 py-2 rounded-full text-sm"><i class="fas fa-search"></i></button>
                <?php if(isset($_GET['cari'])): ?>
                    <a href="?menu=buku" class="bg-slate-300 text-slate-700 px-4 py-2 rounded-full text-sm"><i class="fas fa-times"></i> Reset</a>
                <?php endif; ?>
            </form>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-left">
                <thead class="bg-slate-50 text-slate-500 uppercase text-xs">
                    <tr>
                        <th class="px-6 py-4">Info Buku</th>
                        <th class="px-6 py-4 text-center">Stok</th>
                        <th class="px-6 py-4 text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                    <?php
                    $cari = isset($_GET['cari']) ? "WHERE judul LIKE '%$_GET[cari]%' OR pengarang LIKE '%$_GET[cari]%'" : "";
                    $q = mysqli_query($conn, "SELECT * FROM buku $cari ORDER BY id DESC");
                    if(mysqli_num_rows($q) > 0){
                        while($b = mysqli_fetch_assoc($q)){
                    ?>
                    <tr class="hover:bg-slate-50/80 transition">
                        <td class="px-6 py-4">
                            <div class="font-bold text-slate-800"><?php echo htmlspecialchars($b['judul']); ?></div>
                            <div class="text-sm text-slate-500"><?php echo htmlspecialchars($b['pengarang']); ?></div>
                        </td>
                        <td class="px-6 py-4 text-center">
                            <span class="px-3 py-1 rounded-full text-xs font-bold <?php echo $b['stok'] > 0 ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'; ?>">
                                <?php echo $b['stok']; ?> Tersedia
                            </span>
                        </td>
                        <td class="px-6 py-4 text-center flex justify-center gap-3">
                            <?php if($_SESSION['role']=='user'){ ?>
                                <?php if($b['stok'] > 0){ ?>
                                    <a href="?pinjam=<?php echo $b['id']; ?>" class="bg-indigo-600 text-white px-5 py-2 rounded-full text-sm font-bold hover:bg-indigo-700 transition" onclick="return confirm('Pinjam buku ini?')">
                                        <i class="fas fa-hand-holding"></i> Pinjam
                                    </a>
                                <?php } else { ?>
                                    <span class="text-slate-400 text-sm italic"><i class="fas fa-ban"></i> Habis</span>
                                <?php } ?>
                            <?php } else { ?>
                                <a href="?menu=buku&edit=<?php echo $b['id']; ?>" class="text-indigo-600 hover:text-indigo-800 bg-indigo-50 px-3 py-2 rounded-lg">
                                    <i class="fas fa-edit"></i> Edit
                                </a>
                                <a href="?menu=buku&hapus_buku=<?php echo $b['id']; ?>" class="text-red-500 hover:text-red-700 bg-red-50 px-3 py-2 rounded-lg" onclick="return confirm('Hapus buku <?php echo $b['judul']; ?>?')">
                                    <i class="fas fa-trash"></i> Hapus
                                </a>
                            <?php } ?>
                        </td>
                    </tr>
                    <?php 
                        }
                    } else {
                    ?>
                    <tr>
                        <td colspan="3" class="px-6 py-12 text-center text-slate-500">
                            <i class="fas fa-book-open text-4xl mb-2 block"></i>
                            Tidak ada buku ditemukan
                        </td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>