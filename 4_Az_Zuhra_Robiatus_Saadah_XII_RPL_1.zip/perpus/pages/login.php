<div class="max-w-md mx-auto bg-white p-10 rounded-3xl shadow-xl border border-slate-100">
    <h3 class="text-3xl font-bold text-slate-800 mb-2 text-center">Masuk</h3>
    <p class="text-slate-500 mb-8 text-center text-sm">Akses koleksi buku digital Anda sekarang.</p>
    
    <?php if(isset($_SESSION['login_error'])): ?>
    <div id="errorAlert" class="mb-4 p-4 bg-red-50 border border-red-200 rounded-xl flex items-center gap-3">
        <div class="bg-red-500 rounded-full p-2">
            <i class="fas fa-exclamation text-white text-sm"></i>
        </div>
        <div class="flex-1">
            <p class="text-red-800 font-bold text-sm">GAGAL LOGIN</p>
            <p class="text-red-600 text-sm"><?php echo $_SESSION['login_error']; ?></p>
        </div>
        <button onclick="this.parentElement.style.display='none'" class="text-red-400 hover:text-red-600 transition">
            <i class="fas fa-times-circle"></i>
        </button>
    </div>
    <?php unset($_SESSION['login_error']); endif; ?>
    
    <form method="post" class="space-y-4">
        <input name="username" class="w-full px-4 py-3 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500" placeholder="Username" required>
        <input type="password" name="password" class="w-full px-4 py-3 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500" placeholder="Password" required>
        <button name="login" class="w-full bg-blue-600 text-white py-4 rounded-xl font-bold shadow-lg hover:bg-blue-700 transition">Masuk</button>
    </form>
</div>

<script>
    setTimeout(function() {
        var errorAlert = document.getElementById('errorAlert');
        if(errorAlert) {
            errorAlert.style.opacity = '0';
            errorAlert.style.visibility = 'hidden';
            setTimeout(function() {
                if(errorAlert) errorAlert.style.display = 'none';
            }, 500);
        }
    }, 3000);
</script>