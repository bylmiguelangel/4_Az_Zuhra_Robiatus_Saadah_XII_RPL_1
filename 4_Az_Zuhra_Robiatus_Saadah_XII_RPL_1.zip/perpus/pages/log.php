<div class="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
    <div class="p-6 border-b bg-slate-50/50">
        <div class="flex justify-between items-center flex-wrap gap-4">
            <div>
                <h3 class="font-bold text-xl text-slate-800">📜 Log Aktivitas Sistem</h3>
                <p class="text-sm text-slate-500 mt-1">Mencatat semua perubahan status transaksi oleh admin</p>
            </div>
            <a href="?menu=log" class="text-blue-600 text-sm hover:underline">
                <i class="fas fa-sync-alt"></i> Refresh
            </a>
        </div>
    </div>
    <div class="overflow-x-auto">
        <table class="w-full text-left">
            <thead class="bg-slate-50 text-slate-500 uppercase text-xs">
                <tr>
                    <th class="px-6 py-4">Waktu</th>
                    <th class="px-6 py-4">User</th>
                    <th class="px-6 py-4">Role</th>
                    <th class="px-6 py-4">Aksi</th>
                    <th class="px-6 py-4">Detail</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
                <?php
                $q_log = mysqli_query($conn, "SELECT activity_log.*, users.nama, users.role 
                    FROM activity_log 
                    JOIN users ON activity_log.user_id=users.id 
                    ORDER BY activity_log.id DESC 
                    LIMIT 200");
                
                if(mysqli_num_rows($q_log) > 0){
                    while($log = mysqli_fetch_assoc($q_log)){
                        // Warna badge berdasarkan aksi
                        $badge_color = '';
                        if(strpos($log['action'], 'ADMIN') !== false) {
                            $badge_color = 'bg-purple-100 text-purple-700';
                        } elseif($log['action'] == 'MEMINJAM') {
                            $badge_color = 'bg-blue-100 text-blue-700';
                        } elseif($log['action'] == 'MENGEMBALIKAN') {
                            $badge_color = 'bg-green-100 text-green-700';
                        } elseif($log['action'] == 'HAPUS_TRANSAKSI') {
                            $badge_color = 'bg-red-100 text-red-700';
                        } else {
                            $badge_color = 'bg-slate-100 text-slate-700';
                        }
                ?>
                <tr class="hover:bg-slate-50 transition">
                    <td class="px-6 py-4 text-sm whitespace-nowrap"><?php echo date('d/m/Y H:i:s', strtotime($log['created_at'])); ?></td>
                    <td class="px-6 py-4 font-semibold"><?php echo htmlspecialchars($log['nama']); ?></td>
                    <td class="px-6 py-4">
                        <span class="px-2 py-1 rounded-full text-xs <?php echo $log['role'] == 'admin' ? 'bg-orange-100 text-orange-700' : 'bg-slate-100 text-slate-700'; ?>">
                            <?php echo strtoupper($log['role']); ?>
                        </span>
                    </td>
                    <td class="px-6 py-4">
                        <span class="px-2 py-1 rounded-full text-xs font-bold <?php echo $badge_color; ?>">
                            <?php echo $log['action']; ?>
                        </span>
                    </td>
                    <td class="px-6 py-4 text-sm text-slate-600 max-w-md break-words"><?php echo htmlspecialchars($log['details']); ?></td>
                </tr>
                <?php 
                    }
                } else {
                ?>
                <tr>
                    <td colspan="5" class="px-6 py-12 text-center text-slate-500">
                        <i class="fas fa-history text-4xl mb-2 block"></i>
                        Belum ada aktivitas tercatat
                    </td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
    <div class="p-4 border-t bg-slate-50/50 text-center text-xs text-slate-400">
        <i class="fas fa-info-circle"></i> Menampilkan 200 log terbaru
    </div>
</div>