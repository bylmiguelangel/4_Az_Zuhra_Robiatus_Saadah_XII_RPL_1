<div class="max-w-md mx-auto bg-white p-10 rounded-3xl shadow-xl border border-slate-100">
    <h3 class="text-3xl font-bold text-slate-800 mb-2 text-center">Daftar Akun</h3>
    <p class="text-slate-500 mb-8 text-center text-sm">Bergabunglah untuk meminjam buku.</p>
    
    <form method="post" class="space-y-4">
        <input name="nama" placeholder="Nama Lengkap" class="w-full px-4 py-3 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500" required>
        <input name="username" placeholder="Username" class="w-full px-4 py-3 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500" required>
        <input type="password" name="password" placeholder="Password" class="w-full px-4 py-3 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500" required>
        <button name="daftar" class="w-full bg-blue-600 text-white py-4 rounded-xl font-bold shadow-lg hover:bg-blue-700 transition">Buat Akun Sekarang</button>
    </form>
</div>