<div class="max-w-6xl mx-auto">
    <!-- Welcome Card -->
    <div class="bg-gradient-to-r from-blue-700 to-blue-900 rounded-2xl p-8 text-white shadow-xl mb-8">
        <div class="flex flex-col md:flex-row justify-between items-start md:items-center">
            <div>
                <h2 class="text-3xl font-bold mb-2">Selamat Datang, <?php echo $_SESSION['nama']; ?>!</h2>
                
                <!-- Kutipan berbeda berdasarkan role -->
                <?php if($_SESSION['role'] == 'admin'): ?>
                    <p class="text-blue-200 italic">"Silakan pilih menu di sebelah kiri untuk mengelola data sistem peminjaman buku."</p>
                <?php else: ?>
                    <p class="text-blue-200 italic">"Buku adalah jendela dunia. Mari baca buku hari ini."</p>
                <?php endif; ?>
            </div>
            
            <?php if($_SESSION['role'] == 'admin'): ?>
            <div class="mt-4 md:mt-0 bg-white/20 backdrop-blur-sm px-4 py-2 rounded-full">
                <span class="text-sm font-semibold">🔑 Hak Akses: <?php echo strtoupper($_SESSION['role']); ?></span>
            </div>
            <?php endif; ?>
        </div>
    </div>
    
    <?php
    // ========== PERBAIKAN STATISTIK ==========
    // Total Buku (semua role bisa lihat)
    $total_buku = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM buku"))['total'];
    
    // Total Sedang Dipinjam (filter berdasarkan role)
    if($_SESSION['role'] == 'user'){
        // User hanya melihat buku yang dipinjam oleh dirinya sendiri
        $total_dipinjam = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM transaksi WHERE status='dipinjam' AND user_id = " . $_SESSION['id']))['total'];
    } else {
        // Admin melihat semua buku yang dipinjam
        $total_dipinjam = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM transaksi WHERE status='dipinjam'"))['total'];
    }
    
    // Total Anggota (hanya admin yang lihat)
    $total_user = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM users WHERE role='user'"))['total'];
    // ========================================
    ?>
    
    <!-- Statistik Cards -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <!-- Card Total Buku -->
        <div class="bg-white rounded-2xl p-6 shadow-md border border-slate-100 hover:shadow-lg transition">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-slate-500 text-sm mb-1">Total Buku</p>
                    <p class="text-4xl font-bold text-slate-800"><?php echo $total_buku; ?></p>
                </div>
                <div class="bg-blue-100 p-4 rounded-2xl">
                    <i class="fas fa-book text-blue-600 text-2xl"></i>
                </div>
            </div>
        </div>
        
        <!-- Card Sedang Dipinjam -->
        <div class="bg-white rounded-2xl p-6 shadow-md border border-slate-100 hover:shadow-lg transition">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-slate-500 text-sm mb-1">Sedang Dipinjam</p>
                    <p class="text-4xl font-bold text-slate-800"><?php echo $total_dipinjam; ?></p>
                </div>
                <div class="bg-amber-100 p-4 rounded-2xl">
                    <i class="fas fa-hand-holding text-amber-600 text-2xl"></i>
                </div>
            </div>
        </div>
        
        <!-- Card Total Anggota (Hanya untuk Admin) -->
        <?php if($_SESSION['role'] == 'admin'): ?>
        <div class="bg-white rounded-2xl p-6 shadow-md border border-slate-100 hover:shadow-lg transition">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-slate-500 text-sm mb-1">Total Anggota</p>
                    <p class="text-4xl font-bold text-slate-800"><?php echo $total_user; ?></p>
                </div>
                <div class="bg-green-100 p-4 rounded-2xl">
                    <i class="fas fa-users text-green-600 text-2xl"></i>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
    
</div>